<?php
// Force the browser to treat this as JSON, not HTML
header("Content-Type: application/json");

// Muffle all HTML errors so they don't break the JSON
ini_set('display_errors', 0);

try {
    if (!file_exists("database.php")) {
        throw new Exception("database.php file is missing.");
    }

    require_once("database.php"); // Connects to 'donedb'

    if (!$con) {
        throw new Exception("Database connection failed.");
    }

    $input = file_get_contents("php://input");
    $data = json_decode($input, true);
    $email = isset($data['email']) ? trim($data['email']) : '';

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Please enter a valid email address.");
    }

    $safe_email = mysqli_real_escape_string($con, $email);
    $sql = "INSERT INTO subscribers (email) VALUES ('$safe_email')";

    if (mysqli_query($con, $sql)) {
        echo json_encode(["status" => "success", "message" => "Successfully subscribed!"]);
    } else {
        if (mysqli_errno($con) == 1062) {
            throw new Exception("You are already subscribed.");
        } else {
            throw new Exception("SQL Error: " . mysqli_error($con));
        }
    }

} catch (Exception $e) {
    // Catch any crash and send it as a clean JSON message
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
exit;
?>