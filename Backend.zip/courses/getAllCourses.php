<?php
header("Content-Type: application/json");
require_once("database.php");

$response = array();
$data = array();

$sql = "SELECT id, courseImage, courseName FROM coursetbl";
$result = mysqli_query($con, $sql);

if ($result) {

    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = array(
            "id" => $row["id"],
            "courseImage" => $row["courseImage"],
            "courseName" => $row["courseName"]
        );
    }

    $response["success"] = 1;
    $response["getAllCourses"] = $data;

} else {
    $response["success"] = 0;
    $response["message"] = "Failed to fetch courses";
}

echo json_encode($response);
?>
