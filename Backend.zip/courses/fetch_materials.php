<?php
header("Content-Type: application/json");
require_once("database.php"); //

// --- Handle DELETE Action ---
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    
    // Optional: Fetch paths to delete files from server
    $findSql = "SELECT file_path, image_path FROM materials WHERE id = $id";
    $findRes = mysqli_query($con, $findSql);
    if($row = mysqli_fetch_assoc($findRes)) {
        if(file_exists($row['file_path'])) unlink($row['file_path']);
        if(file_exists($row['image_path'])) unlink($row['image_path']);
    }

    $deleteSql = "DELETE FROM materials WHERE id = $id";
    if(mysqli_query($con, $deleteSql)) {
        echo json_encode(["status" => "success", "message" => "deleted"]);
    } else {
        echo json_encode(["status" => "error", "message" => mysqli_error($con)]);
    }
    exit;
}

// --- Handle FETCH ALL Action ---
$sql = "SELECT * FROM materials ORDER BY id DESC";
$result = mysqli_query($con, $sql);

if (!$result) {
    echo json_encode(["status" => "error", "message" => mysqli_error($con)]);
    exit;
}

$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode($data);
?>
