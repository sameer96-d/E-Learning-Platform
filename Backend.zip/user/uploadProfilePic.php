<?php
require_once("database.php");

$username = $_POST['username'] ?? '';

if ($username == '') {
    echo json_encode(["success" => 0, "message" => "Username missing"]);
    exit;
}

if (!isset($_FILES['profile_picture'])) {
    echo json_encode(["success" => 0, "message" => "No image received"]);
    exit;
}

$file = $_FILES['profile_picture'];
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);

// Unique file name
$filename = $username . "_" . time() . "." . $ext;
$targetPath = "images/" . $filename;

// Upload image
if (move_uploaded_file($file['tmp_name'], $targetPath)) {

    // Save filename in DB
    $sql = "UPDATE donest SET profile_picture='$filename' WHERE username='$username'";
    mysqli_query($con, $sql);

    echo json_encode(["success" => 1, "message" => "Profile picture updated"]);
} else {
    echo json_encode(["success" => 0, "message" => "Upload failed"]);
}
?>
