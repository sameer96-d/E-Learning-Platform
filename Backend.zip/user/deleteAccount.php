<?php
header("Content-Type: application/json");
require_once("database.php");

$response = array();

$username = $_POST['username'] ?? '';

// ✅ Validate input
if ($username === '') {
    $response['success'] = 0;
    $response['message'] = "Username is required";
    echo json_encode($response);
    exit;
}

// ✅ Check if user exists
$checkSql = "SELECT id FROM donest WHERE username = '$username'";
$checkResult = mysqli_query($con, $checkSql);

if (mysqli_num_rows($checkResult) > 0) {

    // ✅ Delete account
    $deleteSql = "DELETE FROM donest WHERE username = '$username'";
    $deleteResult = mysqli_query($con, $deleteSql);

    if ($deleteResult) {
        $response['success'] = 1;
        $response['message'] = "Account deleted successfully";
    } else {
        $response['success'] = 0;
        $response['message'] = "Failed to delete account";
    }

} else {
    $response['success'] = 0;
    $response['message'] = "User not found";
}

echo json_encode($response);
?>
