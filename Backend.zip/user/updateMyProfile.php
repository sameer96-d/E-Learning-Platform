<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");
require_once("database.php");

/* ===== Read & trim input ===== */
$name      = trim($_POST['name'] ?? '');
$mobileno  = trim($_POST['mobileno'] ?? '');
$emailid   = trim($_POST['emailid'] ?? '');
$username  = trim($_POST['username'] ?? '');

/* ===== Validation ===== */
if ($username === '') {
    echo json_encode([
        "success" => 0,
        "message" => "Username is required"
    ]);
    exit;
}

if ($mobileno === '') {
    echo json_encode([
        "success" => 0,
        "message" => "Mobile number not received"
    ]);
    exit;
}

/* ===== Ensure user exists (trim-safe) ===== */
$checkSql = "SELECT id FROM donest WHERE TRIM(username) = '$username'";
$checkRes = mysqli_query($con, $checkSql);

if (mysqli_num_rows($checkRes) === 0) {
    echo json_encode([
        "success" => 0,
        "message" => "User not found"
    ]);
    exit;
}

/* ===== Update profile ===== */
$updateSql = "
    UPDATE donest 
    SET 
        name = '$name',
        mobileno = '$mobileno',
        emailid = '$emailid'
    WHERE TRIM(username) = '$username'
";

$updateRes = mysqli_query($con, $updateSql);

/* ===== Result check ===== */
if ($updateRes && mysqli_affected_rows($con) > 0) {
    echo json_encode([
        "success" => 1,
        "message" => "Profile updated successfully"
    ]);
} else {
    echo json_encode([
        "success" => 0,
        "message" => "No rows updated",
        "affected_rows" => mysqli_affected_rows($con),
        "mysql_error" => mysqli_error($con)
    ]);
}
?>
