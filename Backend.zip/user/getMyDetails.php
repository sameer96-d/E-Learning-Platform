<?php
require_once("database.php");

$username = $_POST['username'] ?? '';

$data = array();

if ($username == '') {
    echo json_encode(['getMyDetails' => []]);
    exit;
}

$sql = "SELECT * FROM donest WHERE username = '$username'";
$result = mysqli_query($con, $sql);

if ($row = mysqli_fetch_assoc($result)) {
    $data[] = array(
        'id' => $row['id'],
        'name' => $row['name'],
        'mobileno' => $row['mobileno'],
        'emailid' => $row['emailid'],
        'username' => $row['username'],
        'profile_picture' => $row['profile_picture']
    );
}

echo json_encode(['getMyDetails' => $data]);
?>
