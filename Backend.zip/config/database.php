<?php
$con = mysqli_connect("127.0.0.1", "root", "", "done"); // Must be 'done'
if (!$con) {
    die(json_encode(["status" => "error", "message" => "Connection failed"]));
}
?>