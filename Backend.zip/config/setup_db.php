<?php
$con = mysqli_connect("127.0.0.1", "root", "");

if (!$con) {
    echo "Connection failed: " . mysqli_connect_error() . "\n";
    exit;
}

$create_db = "CREATE DATABASE IF NOT EXISTS donedb";
if (mysqli_query($con, $create_db)) {
    echo "Database 'donedb' created or already exists.\n";
} else {
    echo "Failed to create database: " . mysqli_error($con) . "\n";
}

mysqli_select_db($con, "donedb");

$create_donest = "CREATE TABLE IF NOT EXISTS donest (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    mobileno VARCHAR(20) NOT NULL,
    emailid VARCHAR(255) NOT NULL UNIQUE,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    profile_picture VARCHAR(255) DEFAULT NULL
)";

$create_materials = "CREATE TABLE IF NOT EXISTS materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    details TEXT,
    file_path VARCHAR(255),
    image_path VARCHAR(255),
    file_type VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

$create_subscribers = "CREATE TABLE IF NOT EXISTS subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if (mysqli_query($con, $create_donest)) {
    echo "Table 'donest' created.\n";
} else {
    echo "Error creating 'donest': " . mysqli_error($con) . "\n";
}

if (mysqli_query($con, $create_materials)) {
    echo "Table 'materials' created.\n";
} else {
    echo "Error creating 'materials': " . mysqli_error($con) . "\n";
}

if (mysqli_query($con, $create_subscribers)) {
    echo "Table 'subscribers' created.\n";
} else {
    echo "Error creating 'subscribers': " . mysqli_error($con) . "\n";
}

mysqli_close($con);
echo "Setup complete.\n";
?>