<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("database.php");

if (!$con) {
    echo "<b>DATABASE ERROR:</b> Connection failed! Check your database.php.";
} else {
    echo "<b>SUCCESS:</b> Database 'donedb' is connected! <br>";
    
    $check_table = mysqli_query($con, "DESCRIBE subscribers");
    if (!$check_table) {
        echo "<b>TABLE ERROR:</b> The 'subscribers' table does not exist in 'donedb'.";
    } else {
        echo "<b>ALL GOOD:</b> Table 'subscribers' is ready!";
    }
}
?>