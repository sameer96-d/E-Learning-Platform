<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing database connection...\n";

$con = mysqli_connect("127.0.0.1", "root", "", "donedb");

if (!$con) {
    echo "Connection failed: " . mysqli_connect_error() . "\n";
    echo "Attempting to create database...\n";
    $con_temp = mysqli_connect("127.0.0.1", "root", "");
    if (!$con_temp) {
        echo "Cannot connect to MySQL at all: " . mysqli_connect_error() . "\n";
        exit;
    }
    $create_db = "CREATE DATABASE IF NOT EXISTS donedb";
    if (mysqli_query($con_temp, $create_db)) {
        echo "Database 'donedb' created.\n";
        mysqli_select_db($con_temp, "donedb");
        $con = $con_temp;
    } else {
        echo "Failed to create database: " . mysqli_error($con_temp) . "\n";
        exit;
    }
}

echo "Connected successfully!\n";

mysqli_set_charset($con, 'utf8mb4');

// Create tables if they don't exist
$create_donest = "CREATE TABLE IF NOT EXISTS donest (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    mobileno VARCHAR(20) NOT NULL,
    emailid VARCHAR(255) NOT NULL UNIQUE,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    profile_picture VARCHAR(255) DEFAULT NULL
)";

$create_materials = "CREATE TABLE IF NOT EXISTS materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    details TEXT,
    file_path VARCHAR(255),
    image_path VARCHAR(255),
    file_type VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

$create_subscribers = "CREATE TABLE IF NOT EXISTS subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if (mysqli_query($con, $create_donest)) {
    echo "Table 'donest' ready.\n";
} else {
    echo "Error creating 'donest': " . mysqli_error($con) . "\n";
}

if (mysqli_query($con, $create_materials)) {
    echo "Table 'materials' ready.\n";
} else {
    echo "Error creating 'materials': " . mysqli_error($con) . "\n";
}

if (mysqli_query($con, $create_subscribers)) {
    echo "Table 'subscribers' ready.\n";
} else {
    echo "Error creating 'subscribers': " . mysqli_error($con) . "\n";
}

mysqli_close($con);
echo "Setup complete. Login should now work.\n";
?>