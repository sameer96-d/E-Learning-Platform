<?php
$con = mysqli_connect("127.0.0.1", "root", "");

if (!$con) {
    echo "Connection failed: " . mysqli_connect_error() . "\n";
} else {
    echo "Connected to MySQL successfully.\n";
    mysqli_close($con);
}
?>