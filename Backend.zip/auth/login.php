<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once("database.php");

// 1. Get the POST data
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    echo json_encode(["status" => "error", "message" => "Fields are empty"]);
    exit;
}

$username = mysqli_real_escape_string($con, $username);
$password = mysqli_real_escape_string($con, $password);

// 2. Run the query - and catch the error if the table name is wrong
$sql = "SELECT * FROM donest WHERE username='$username' AND password='$password'";
$result = mysqli_query($con, $sql);

if (!$result) {
    echo json_encode(["status" => "error", "message" => "Database Error: " . mysqli_error($con)]);
    exit;
}

if (mysqli_num_rows($result) > 0) {
    echo json_encode(["status" => "success", "message" => "Login successful"]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid username or password"]);
}
?>