<?php

require_once("database.php");

$response = array();

$username = $_POST['username'] ?? '';
$emailid = $_POST['emailid'] ?? '';
$password = $_POST['password'] ?? '';

if($password != '')
{

    // Case 1 : username provided
    if($username != '')
    {
        $sql = "SELECT * FROM donest WHERE username='$username'";
        $result = mysqli_query($con,$sql);

        if(mysqli_num_rows($result) > 0)
        {

            $sql1 = "UPDATE donest SET password='$password' WHERE username='$username'";
            $result1 = mysqli_query($con,$sql1);

            $response["success"] = 1;
            $response["message"] = "Password Updated Using Username";

        }
        else
        {
            $response["success"] = 0;
            $response["message"] = "Username not found";
        }
    }

    // Case 2 : emailid provided
    else if($emailid != '')
    {
        $sql = "SELECT * FROM donest WHERE emailid='$emailid'";
        $result = mysqli_query($con,$sql);

        if(mysqli_num_rows($result) > 0)
        {

            $sql1 = "UPDATE donest SET password='$password' WHERE emailid='$emailid'";
            $result1 = mysqli_query($con,$sql1);

            $response["success"] = 1;
            $response["message"] = "Password Updated Using EmailID";

        }
        else
        {
            $response["success"] = 0;
            $response["message"] = "EmailID not found";
        }
    }

    else
    {
        $response["success"] = 0;
        $response["message"] = "Enter Username or EmailID";
    }

}
else
{
    $response["success"] = 0;
    $response["message"] = "Password missing";
}

echo json_encode($response);

?>