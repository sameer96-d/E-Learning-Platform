<?php
header("Content-Type: application/json");
require_once("database.php");

$name = trim($_POST['name'] ?? '');
$mobileno = trim($_POST['mobileno'] ?? '');
$emailid = trim($_POST['emailid'] ?? '');
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($name === '' || $mobileno === '' || $emailid === '' || $username === '' || $password === '') {
    echo json_encode([
        "status" => "error",
        "message" => "All fields are required"
    ]);
    exit;
}

$name = mysqli_real_escape_string($con, $name);
$mobileno = mysqli_real_escape_string($con, $mobileno);
$emailid = mysqli_real_escape_string($con, $emailid);
$username = mysqli_real_escape_string($con, $username);
$password = mysqli_real_escape_string($con, $password);

$checkSql = "SELECT id FROM donest WHERE username='$username' OR emailid='$emailid' LIMIT 1";
$checkRes = mysqli_query($con, $checkSql);
if (!$checkRes) {
    echo json_encode(["status" => "error", "message" => "Database error: " . mysqli_error($con)]);
    exit;
}

if (mysqli_num_rows($checkRes) > 0) {
    echo json_encode(["status" => "error", "message" => "Username or email already exists"]);
    exit;
}

$sql = "INSERT INTO donest (name, mobileno, emailid, username, password)
        VALUES ('$name','$mobileno','$emailid','$username','$password')";

if (mysqli_query($con, $sql)) {
    echo json_encode([
        "status" => "success",
        "message" => "Registration successful"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Registration failed: " . mysqli_error($con)
    ]);
}
?>

