document.addEventListener("DOMContentLoaded", () => {
    const newsletterForm = document.getElementById("newsletterForm");

    if (newsletterForm) {
        newsletterForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            
            const emailInput = document.getElementById("subscriberEmail");
            const btn = newsletterForm.querySelector("button");

            btn.innerText = "...";
            btn.disabled = true;

            try {
                // Try sending the request
                const response = await fetch("subscribe.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email: emailInput.value })
                });

                // If the server returns a 404 or 500 error
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const result = await response.json();
                alert(result.message);

                if (result.status === "success") {
                    emailInput.value = ""; 
                }

            } catch (error) {
                // This will now tell us EXACTLY what went wrong
                alert("Connection Error: " + error.message);
                console.error("Full Error Details:", error);
            } finally {
                btn.innerText = "Join";
                btn.disabled = false;
            }
        });
    }
}); 