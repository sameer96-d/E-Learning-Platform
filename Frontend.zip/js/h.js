/* =========================================================
   CORE INITIALIZATION & LOAD DATA
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
    const username = localStorage.getItem("username");
    if (!username) {
        window.location.replace("index.html");
        return;
    }

    const data = new URLSearchParams();
    data.append("username", username);

    fetch("getMyDetails.php", {
        method: "POST",
        body: data
    })
    .then(res => res.json())
    .then(d => {
        if (d.getMyDetails && d.getMyDetails.length > 0) {
            const user = d.getMyDetails[0];
            document.getElementById("helloName").innerText = "Hello, " + user.name;
            document.getElementById("pname").value = user.name;
            document.getElementById("pemail").value = user.emailid;
            document.getElementById("pmobile").value = user.mobileno;
            document.getElementById("pusername").value = user.username;

            if (user.profile_picture) {
                const img = document.getElementById("profileImg");
                img.src = "images/" + user.profile_picture;
                img.style.display = "block";
                document.getElementById("profileIcon").style.display = "none";
            }
        }
    })
    .catch(() => console.error("Data load failed"));
});

/* =========================================================
   PROFILE POPUP TOGGLE & CLICK OUTSIDE
   ========================================================= */
function toggleProfile() {
    document.getElementById("profilePanel").classList.toggle("open");
}

window.addEventListener("click", function(e) {
    const panel = document.getElementById("profilePanel");
    const profileBtn = document.querySelector(".nav-right");
    if (panel && panel.classList.contains("open") && !panel.contains(e.target) && !profileBtn.contains(e.target)) {
        panel.classList.remove("open");
    }
});

/* =========================================================
   ACTIONS: UPDATE, FOCUS, UPLOAD, DELETE
   ========================================================= */
function focusInput(iconElement) {
    const input = iconElement.parentElement.querySelector('input');
    if (input) {
        input.focus();
        const len = input.value.length;
        input.setSelectionRange(len, len);
    }
}

function updateProfile() {
    const data = new URLSearchParams();
    data.append("name", document.getElementById("pname").value);
    data.append("emailid", document.getElementById("pemail").value);
    data.append("mobileno", document.getElementById("pmobile").value);
    data.append("username", document.getElementById("pusername").value);

    fetch("updateMyProfile.php", {
        method: "POST",
        body: data
    })
    .then(res => res.json())
    .then(d => alert(d.message))
    .catch(() => alert("Update failed"));
}

function chooseProfilePic() { document.getElementById("profileInput").click(); }

const profileInput = document.getElementById("profileInput");
if(profileInput) {
    profileInput.addEventListener("change", function () {
        const file = this.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = e => {
            const img = document.getElementById("profileImg");
            img.src = e.target.result;
            img.style.display = "block";
            document.getElementById("profileIcon").style.display = "none";
            uploadProfileImage(file);
        };
        reader.readAsDataURL(file);
    });
}

function uploadProfileImage(file) {
    const formData = new FormData();
    formData.append("profile_picture", file);
    formData.append("username", localStorage.getItem("username"));
    fetch("uploadProfilePic.php", { method: "POST", body: formData })
    .then(res => res.json()).then(d => alert(d.message))
    .catch(() => alert("Upload failed"));
}

function confirmDelete() {
    const username = localStorage.getItem("username");
    if (confirm("Are you sure? This will permanently delete your account.")) {
        const data = new URLSearchParams();
        data.append("username", username);
        fetch("deleteAccount.php", { method: "POST", body: data })
        .then(res => res.json())
        .then(d => {
            if (d.success === 1) {
                alert(d.message);
                localStorage.removeItem("username");
                window.location.replace("index.html");
            } else {
                alert("Error: " + d.message);
            }
        });
    }
}

function logoutUser() {
    localStorage.removeItem("username");
    window.location.replace("index.html");
}

/* =========================================================
   HOME PAGE BACK BUTTON FIX
   ========================================================= */
if (window.location.pathname.includes("home.html")) {
    history.pushState(null, "", location.href);
    window.onpopstate = function () {
        window.location.href = "index.html";
    };
}
