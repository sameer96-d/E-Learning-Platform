function filterComm() {
    const query = document.getElementById('commSearch').value.toLowerCase();
    const modules = document.querySelectorAll('.doc-section');
    const empty = document.getElementById('noResults');
    let found = 0;

    modules.forEach(card => {
        const text = card.innerText.toLowerCase();
        if (text.includes(query)) {
            card.style.display = "block";
            found++;
        } else {
            card.style.display = "none";
        }
    });

    if (empty) {
        empty.style.display = (found === 0 && query !== "") ? "block" : "none";
    }
}

// Persist speech drafts
const commArea = document.getElementById('commNotes');
const COMM_KEY = 'mountreach_comm_drafts';

window.addEventListener('load', () => {
    const saved = localStorage.getItem(COMM_KEY);
    if (saved && commArea) commArea.value = saved;
});

if (commArea) {
    commArea.addEventListener('input', () => {
        localStorage.setItem(COMM_KEY, commArea.value);
    });
}

function clearCommNotes() {
    if (confirm("Clear your leadership scripts?")) {
        commArea.value = "";
        localStorage.removeItem(COMM_KEY);
    }
}