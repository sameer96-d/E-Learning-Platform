function filterLaTeX() {
    const query = document.getElementById('latexSearch').value.toLowerCase();
    const modules = document.querySelectorAll('.doc-section');
    const empty = document.getElementById('noResults');
    let found = 0;

    modules.forEach(card => {
        const text = card.innerText.toLowerCase();
        if (text.includes(query)) {
            card.style.display = "block";
            found++;
        } else {
            card.style.display = "none";
        }
    });

    if (empty) {
        empty.style.display = (found === 0 && query !== "") ? "block" : "none";
    }
}

// Persist LaTeX drafts
const latexArea = document.getElementById('latexNotes');
const LATEX_KEY = 'mountreach_latex_notes';

window.addEventListener('load', () => {
    const saved = localStorage.getItem(LATEX_KEY);
    if (saved && latexArea) latexArea.value = saved;
});

if (latexArea) {
    latexArea.addEventListener('input', () => {
        localStorage.setItem(LATEX_KEY, latexArea.value);
    });
}

function clearLatexNotes() {
    if (confirm("Delete your LaTeX scratchpad?")) {
        latexArea.value = "";
        localStorage.removeItem(LATEX_KEY);
    }
}