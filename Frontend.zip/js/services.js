/* =========================================================
   POPUP NOTIFICATION LOGIC
   ========================================================= */
function showNotice() {
    // A professional native alert
    alert("Coming soon: This section is currently under development. Please check back later!");
}