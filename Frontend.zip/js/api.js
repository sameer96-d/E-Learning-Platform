function filterAPI() {
    const query = document.getElementById('apiSearch').value.toLowerCase();
    const modules = document.querySelectorAll('.doc-section');
    const empty = document.getElementById('noResults');
    let found = 0;

    modules.forEach(card => {
        const text = card.innerText.toLowerCase();
        if (text.includes(query)) {
            card.style.display = "block";
            found++;
        } else {
            card.style.display = "none";
        }
    });

    if (empty) {
        empty.style.display = (found === 0 && query !== "") ? "block" : "none";
    }
}

// Persist API notes
const apiArea = document.getElementById('apiNotes');
const API_KEY = 'mountreach_api_log';

window.addEventListener('load', () => {
    const saved = localStorage.getItem(API_KEY);
    if (saved && apiArea) apiArea.value = saved;
});

if (apiArea) {
    apiArea.addEventListener('input', () => {
        localStorage.setItem(API_KEY, apiArea.value);
    });
}

function clearApiNotes() {
    if (confirm("Permanently delete your API drafts?")) {
        apiArea.value = "";
        localStorage.removeItem(API_KEY);
    }
}