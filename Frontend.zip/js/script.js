let active = false;

// ===== SAFE ELEMENT REFERENCES =====
const box = document.getElementById("box");
const title = document.getElementById("title");
const desc = document.getElementById("desc");
const switchBtn = document.getElementById("switchBtn");
const msg = document.getElementById("msg");
const loginMsg = document.getElementById("loginMsg");

/* ================= TOGGLE ================= */
window.toggle = function() {
    active = !active;
    box.classList.toggle("active");

    if (active) {
        title.innerText = "New Here?";
        desc.innerText = "Create an account with us";
        switchBtn.innerText = "Register";
    } else {
        title.innerText = "Hello, Friend!";
        desc.innerText = "Already have an account?";
        switchBtn.innerText = "Login";
    }
}

/* ================= REGISTER ================= */
window.register = function() {
    console.log("Register attempt started..."); 
    const name = document.getElementById("rname").value.trim();
    const mobile = document.getElementById("rmobile").value.trim();
    const email = document.getElementById("remail").value.trim();
    const username = document.getElementById("ruser").value.trim();
    const password = document.getElementById("rpass").value.trim();

    if (!name || !mobile || !email || !username || !password) {
        msg.innerText = "Please enter all details";
        msg.style.color = "red";
        return;
    }

    const data = new URLSearchParams();
    data.append("name", name);
    data.append("mobileno", mobile);
    data.append("emailid", email);
    data.append("username", username);
    data.append("password", password);

    // Using relative path to match whatever port Apache is using
    fetch("register.php", {
        method: "POST",
        body: data
    })
    .then(res => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
    })
    .then(d => {
        if (d.status === "error") {
            msg.innerText = d.message;
            msg.style.color = "red";
            return;
        }
        msg.innerText = d.message;
        msg.style.color = d.status === "success" ? "green" : "red";

        if (d.status === "success") {
            localStorage.setItem("username", username);
            setTimeout(() => {
                window.location.href = "home.html";
            }, 1500);
        }
    })
    .catch((err) => {
        console.error("Register Error:", err);
        msg.innerText = "Server error! Check if PHP is running.";
        msg.style.color = "red";
    });
}

/* ================= LOGIN ================= */
window.login = function() {
    console.log("Login attempt started..."); 
    const username = document.getElementById("luser").value.trim();
    const password = document.getElementById("lpass").value.trim();

    if (!username || !password) {
        loginMsg.innerText = "Please enter username and password";
        loginMsg.style.color = "red";
        return;
    }

    const data = new URLSearchParams();
    data.append("username", username);
    data.append("password", password);

    fetch("login.php", {
        method: "POST",
        body: data
    })
    .then(res => {
        if (!res.ok) throw new Error("Server returned " + res.status);
        return res.json();
    })
    .then(d => {
        if (d.status === "error") {
            loginMsg.innerText = d.message;
            loginMsg.style.color = "red";
            return;
        }
        loginMsg.innerText = d.message;
        loginMsg.style.color = d.status === "success" ? "green" : "red";

        if (d.status === "success") {
            localStorage.setItem("username", username);
            setTimeout(() => {
                window.location.href = "home.html";
            }, 800);
        }
    })
    .catch((err) => {
        console.error("Login Error:", err);
        loginMsg.innerText = "Server error! Check login.php/database.php.";
        loginMsg.style.color = "red";
    });
}