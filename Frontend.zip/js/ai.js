/**
 * MOUNTREACH SOLUTION - GLOBAL SEARCH & NOTEPAD
 * Enhanced to scan all textual content on the page.
 */

function filterDocs() {
    const query = document.getElementById('docSearch').value.toLowerCase();
    const modules = document.querySelectorAll('.doc-section');
    const pageHeader = document.querySelector('.page-intro');
    const emptyState = document.getElementById('noResults');
    let foundCount = 0;

    // 1. Search through curriculum modules
    modules.forEach(card => {
        const contentText = card.innerText.toLowerCase();
        const dataTitle = card.getAttribute('data-title').toLowerCase();

        if (contentText.includes(query) || dataTitle.includes(query)) {
            card.style.display = "block";
            card.style.animation = "fadeIn 0.3s ease";
            foundCount++;
        } else {
            card.style.display = "none";
        }
    });

    // 2. Search through the page intro header
    if (pageHeader) {
        const headerText = pageHeader.innerText.toLowerCase();
        pageHeader.style.display = (headerText.includes(query) || foundCount > 0) ? "block" : "none";
    }

    // 3. Handle "No Results" state
    if (emptyState) {
        emptyState.style.display = (foundCount === 0 && query !== "") ? "block" : "none";
    }
}

// Notepad Persistent Logic
const notesBox = document.getElementById('instantNotes');
const STORAGE_KEY = 'mountreach_ai_study_notes';

window.addEventListener('load', () => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved && notesBox) notesBox.value = saved;
});

if (notesBox) {
    notesBox.addEventListener('input', () => {
        localStorage.setItem(STORAGE_KEY, notesBox.value);
    });
}

function clearNotes() {
    if (confirm("Permanently delete your AI module notes?")) {
        notesBox.value = "";
        localStorage.removeItem(STORAGE_KEY);
    }
}