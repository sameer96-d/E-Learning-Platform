/* =========================================================
   LANDING PAGE REDIRECTION
   ========================================================= */
function openPortal() {
    // Redirects directly to your index.html as requested
    window.location.href = "index.html";
}

/* =========================================================
   ENTRY ANIMATION
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
    const heroText = document.querySelector(".hero-text");
    const heroImage = document.querySelector(".hero-image");

    // Professional Fade-in effect
    heroText.style.opacity = "0";
    heroText.style.transform = "translateX(-30px)";
    heroImage.style.opacity = "0";
    heroImage.style.transform = "translateX(30px)";

    setTimeout(() => {
        heroText.style.transition = "all 0.8s ease-out";
        heroText.style.opacity = "1";
        heroText.style.transform = "translateX(0)";

        heroImage.style.transition = "all 0.8s ease-out";
        heroImage.style.opacity = "1";
        heroImage.style.transform = "translateX(0)";
    }, 200);
});