document.addEventListener("DOMContentLoaded", () => {
    const heroElements = document.querySelectorAll(".text-block, .visual-block");
    
    // Smooth scroll-in animation
    heroElements.forEach((el, index) => {
        el.style.opacity = "0";
        el.style.transform = index === 0 ? "translateX(-30px)" : "translateX(30px)";
        
        setTimeout(() => {
            el.style.transition = "all 1s cubic-bezier(0.2, 0.8, 0.2, 1)";
            el.style.opacity = "1";
            el.style.transform = "translateX(0)";
        }, 150 * (index + 1));
    });
});