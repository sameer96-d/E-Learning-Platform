document.addEventListener("DOMContentLoaded", () => {
    const mapBtn = document.getElementById("viewMap");

    mapBtn.addEventListener("click", () => {
        // Precise location from contact info
        const address = "Near Saraswati Vidyalaya, Dastur Nagar, Amravati, Maharashtra 444607";
        const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
        
        window.open(url, '_blank');
    });
});