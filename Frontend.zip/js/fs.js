function filterFS() {
    const query = document.getElementById('fsSearch').value.toLowerCase();
    const modules = document.querySelectorAll('.doc-section');
    const empty = document.getElementById('noResults');
    let found = 0;

    modules.forEach(card => {
        const text = card.innerText.toLowerCase();
        if (text.includes(query)) {
            card.style.display = "block";
            found++;
        } else {
            card.style.display = "none";
        }
    });

    if (empty) {
        empty.style.display = (found === 0 && query !== "") ? "block" : "none";
    }
}

// Persist dev log
const fsArea = document.getElementById('fsNotes');
const FS_KEY = 'mountreach_fs_log';

window.addEventListener('load', () => {
    const saved = localStorage.getItem(FS_KEY);
    if (saved && fsArea) fsArea.value = saved;
});

if (fsArea) {
    fsArea.addEventListener('input', () => {
        localStorage.setItem(FS_KEY, fsArea.value);
    });
}

function clearFSNotes() {
    if (confirm("Clear your technical dev log?")) {
        fsArea.value = "";
        localStorage.removeItem(FS_KEY);
    }
}