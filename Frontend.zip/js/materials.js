/* =========================================================
   DYNAMIC MATERIALS & SEARCH LOGIC
   ========================================================= */

document.addEventListener("DOMContentLoaded", fetchMaterials);

/**
 * 1. FETCH DYNAMIC DATA FROM DATABASE
 */
async function fetchMaterials() {
    try {
        const res = await fetch("fetch_materials.php");
        const data = await res.json();

        if (data.status === "error") {
            throw new Error(data.message || "Unable to fetch materials.");
        }

        renderMaterials(data);
        initSearch(); // Initialize search after cards are created
    } catch (err) {
        console.error("Database connection error:", err);
        document.querySelector('.grid-container').innerHTML = `<p style="padding:40px; text-align:center; color:#ef4444;">Unable to load materials. Please ensure MySQL is running and refresh.</p>`;
    }
}

/**
 * 2. RENDER CARDS WITH CONSISTENT UI
 */
function renderMaterials(items) {
    const grid = document.getElementById('materialsGrid');
    const counter = document.getElementById('materialCounter'); // ID for "Total Items"
    
    if(counter) counter.innerText = items.length;
    grid.innerHTML = ''; 

    items.forEach(item => {
        grid.innerHTML += `
            <div class="card" style="display: flex;">
                <div class="card-image">
                    <img src="${item.image_path}" alt="${item.title}" class="note-img">
                </div>
                <div class="card-body">
                    <span class="category">${item.file_type.toUpperCase()} Resource</span>
                    <h3>${item.title}</h3>
                    <p>${item.details}</p>
                    <div class="card-action">
                        <span class="file-info">Digital Note</span>
                        <a href="${item.file_path}" download class="download-btn">
                            Download <i class="fa-solid fa-download"></i>
                        </a>
                    </div>
                </div>
            </div>
        `;
    });
}

/**
 * 3. INITIALIZE SEARCH LOGIC
 */
function initSearch() {
    const searchInput = document.getElementById("materialSearch");
    
    searchInput.addEventListener("input", (e) => {
        const searchTerm = e.target.value.toLowerCase().trim();
        const materialCards = document.querySelectorAll(".card");

        materialCards.forEach(card => {
            const title = card.querySelector("h3").innerText.toLowerCase();
            const category = card.querySelector(".category").innerText.toLowerCase();
            const description = card.querySelector("p").innerText.toLowerCase();

            if (title.includes(searchTerm) || 
                category.includes(searchTerm) || 
                description.includes(searchTerm)) {
                
                card.style.display = "flex";
                card.style.animation = "fadeIn 0.4s ease";
            } else {
                card.style.display = "none";
            }
        });

        handleNoResults(searchTerm);
    });
}

/**
 * 4. EMPTY STATE FEEDBACK
 */
function handleNoResults(term) {
    let noResultsMsg = document.getElementById("no-results");
    const visibleCards = document.querySelectorAll(".card[style*='display: flex']").length;

    if (visibleCards === 0 && term !== "") {
        if (!noResultsMsg) {
            noResultsMsg = document.createElement("p");
            noResultsMsg.id = "no-results";
            noResultsMsg.className = "no-results-msg"; // Style this in CSS
            noResultsMsg.style.gridColumn = "1 / -1";
            noResultsMsg.style.textAlign = "center";
            noResultsMsg.style.color = "#64748b";
            noResultsMsg.style.padding = "40px";
            noResultsMsg.innerHTML = `<i class="fa-solid fa-face-frown"></i> No materials found for "${term}"`;
            document.querySelector(".grid-container").appendChild(noResultsMsg);
        }
    } else if (noResultsMsg) {
        noResultsMsg.remove();
    }
}