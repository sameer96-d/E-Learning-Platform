/* =========================================================
   FORGET PASSWORD PAGE LOGIC
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {
    const passInput = document.getElementById("password");
    const repassInput = document.getElementById("re-password");
    const matchStatus = document.getElementById("matchStatus");
    const resetForm = document.getElementById("resetForm");

    // ===== 1. REAL-TIME VALIDATION =====
    repassInput.addEventListener("input", () => {
        const pass = passInput.value;
        const repass = repassInput.value;

        if (repass === "") {
            repassInput.classList.remove("match", "no-match");
            matchStatus.innerHTML = "";
            return;
        }

        if (pass === repass) {
            repassInput.classList.remove("no-match");
            repassInput.classList.add("match");
            matchStatus.innerHTML = '<i class="fa-solid fa-circle-check"></i> Passwords match';
            matchStatus.classList.remove("error");
            matchStatus.classList.add("success");
        } else {
            repassInput.classList.remove("match");
            repassInput.classList.add("no-match");
            matchStatus.innerHTML = '<i class="fa-solid fa-circle-exclamation"></i> Passwords don\'t match';
            matchStatus.classList.remove("success");
            matchStatus.classList.add("error");
        }
    });

    // ===== 2. BACKEND INTEGRATION =====
    resetForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        // Prevent submission if passwords don't match
        if (repassInput.classList.contains("no-match")) {
            alert("Please ensure both passwords match before continuing.");
            repassInput.focus();
            return;
        }

        const formData = new FormData(resetForm);
        const idInput = resetForm.querySelector('input[name="username"]');
        const idValue = idInput.value.trim();

        // Smart mapping for backend cases
        const data = new URLSearchParams();
        data.append("password", passInput.value);

        if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(idValue)) {
            data.append("emailid", idValue);
        } else {
            data.append("username", idValue);
        }

        try {
            const response = await fetch("forgetPassword.php", {
                method: "POST",
                body: data
            });

            const result = await response.json();

            if (result.success === 1) {
                // ✅ SUCCESS
                matchStatus.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${result.message}`;
                matchStatus.className = "match-msg success";
                idInput.style.borderColor = "var(--success)";
                setTimeout(() => { window.location.href = "index.html"; }, 2000);
            } else {
                // ❌ ERROR
                matchStatus.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${result.message}`;
                matchStatus.className = "match-msg error";
                idInput.style.borderColor = "var(--error)";
                idInput.classList.add("shake-animation"); 
                setTimeout(() => idInput.classList.remove("shake-animation"), 500);
            }
        } catch (error) {
            matchStatus.innerText = "Connection error. Please try again.";
            matchStatus.className = "match-msg error";
        }
    });
});

// ===== 3. SHOW/HIDE PASSWORD TOGGLE =====
function togglePassword(inputId, icon) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
    } else {
        input.type = "password";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    }
}