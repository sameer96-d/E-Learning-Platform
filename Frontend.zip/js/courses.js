/* =========================================================
   COURSES PAGE BACK NAVIGATION
   ========================================================= */
// 1. Force override h.js behavior immediately
window.onpopstate = null;

// 2. Set the destination
window.onpopstate = function() {
    window.location.replace("home.html");
};

// 3. Create the history point
history.pushState(null, "", location.href);

/* =========================================================
   RENDER LOGIC
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
    renderCourses();
});

function renderCourses() {
    const container = document.getElementById("courseContainer");

    const courses = [
        { name: "Full Stack Development using Java", image: "images/fsjava.jpg" },
        { name: "Web development using MERN stack", image: "images/mern.png" },
        { name: "Web development using Python", image: "images/python.jpg" },
        { name: "Web Development using PHP", image: "images/PHP.jpg" },
        { name: "Internet Of Things (IOT)", image: "images/iot.jpg" },
        { name: "Data Analytics", image: "images/dataa.jpg" }
    ];

    if (container) {
        container.innerHTML = ""; 
        courses.forEach(course => {
            container.innerHTML += `
                <div class="course-card">
                    <img src="${course.image}" alt="${course.name}">
                    <div class="course-info">
                        <h3>${course.name}</h3>
                        <button class="enroll-btn">Enroll Now</button>
                    </div>
                </div>
            `;
        });
    }
}