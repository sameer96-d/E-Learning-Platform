/* =========================================================
   SYSTEM ADMIN DASHBOARD LOGIC
   ========================================================= */

document.addEventListener("DOMContentLoaded", fetchMaterials);

// Update file display names and highlight box on selection
function updateFileName(inputId, displayId) {
    const input = document.getElementById(inputId);
    const display = document.getElementById(displayId);
    if (input.files.length > 0) {
        display.innerText = input.files[0].name;
        display.style.color = "#10b981";
        input.parentElement.classList.add("selected");
    }
}

// ===== 1. MODAL TOGGLE =====
function openModal() {
    const modal = document.getElementById('uploadModal');
    modal.style.display = 'flex'; // Centering with flex
}

function closeModal() {
    const modal = document.getElementById('uploadModal');
    modal.style.display = 'none';
    document.getElementById('uploadForm').reset();
    document.querySelectorAll('.file-box').forEach(b => b.classList.remove('selected'));
    document.getElementById('fileNameDisplay').innerText = "Source (PDF/Video)";
    document.getElementById('imageNameDisplay').innerText = "Display Image";
}

// Close modal when clicking on the dark background
window.onclick = (e) => {
    const modal = document.getElementById('uploadModal');
    if (e.target === modal) closeModal();
};

// ===== 2. DATA MANAGEMENT (FETCH) =====
async function fetchMaterials() {
    try {
        const res = await fetch("fetch_materials.php");
        const data = await res.json();

        if (data.status === "error") {
            console.error("Fetch error:", data.message);
            alert("Unable to load materials: " + data.message);
            return;
        }
        renderTable(data);
    } catch (err) {
        console.error("Failed to fetch:", err);
        alert("Unable to load materials. Please ensure MySQL is running and reload the page.");
    }
}

// ===== 3. UPLOAD HANDLER (DYNAMIC) =====
document.getElementById('uploadForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = document.getElementById('submitBtn');
    btn.innerText = "Publishing...";
    btn.disabled = true;

    const formData = new FormData();
    formData.append('title', document.getElementById('materialTitle').value);
    formData.append('details', document.getElementById('materialDetails').value);
    formData.append('file', document.getElementById('fileSource').files[0]);
    formData.append('image', document.getElementById('imageSource').files[0]);

    try {
        const res = await fetch("upload.php", { method: "POST", body: formData });
        const result = await res.json();

        if (result.status === "success") {
            closeModal();
            this.reset();
            fetchMaterials(); // Reload list to stay dynamic
        } else {
            alert(result.message || "Publish failed.");
        }
    } catch (err) {
        alert("Server error. Check your PHP path and database connection.");
    } finally {
        btn.innerText = "Publish Material";
        btn.disabled = false;
    }
});

// ===== 4. DELETE HANDLER =====
async function deleteMaterial(id) {
    if (confirm("Delete this resource permanently?")) {
        try {
            await fetch(`fetch_materials.php?delete_id=${id}`);
            fetchMaterials();
        } catch (err) {
            alert("Error deleting record.");
        }
    }
}

// ===== 5. UI RENDERER (TABLE) =====
function renderTable(materials) {
    const list = document.getElementById('materialList');
    const counter = document.getElementById('materialCounter');
    
    list.innerHTML = '';
    materials.forEach(item => {
        const dateStr = new Date(item.created_at).toLocaleDateString();
        
        list.innerHTML += `
            <tr>
                <td><img src="${item.image_path}" style="width:65px; height:45px; border-radius:6px; object-fit:cover;"></td>
                <td>
                    <div style="font-weight:700; color:#0f172a">${item.title}</div>
                    <div style="font-size:12px; color:#64748b">${item.details}</div>
                </td>
                <td><span style="background:#f1f5f9; padding:4px 8px; border-radius:6px; font-size:11px; font-weight:800;">${item.file_type.toUpperCase()}</span></td>
                <td style="font-size:13px; color:#64748b">${dateStr}</td>
                <td>
                    <button onclick="deleteMaterial(${item.id})" style="color:#f43f5e; background:none; border:none; cursor:pointer;">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    counter.innerText = materials.length; // Live count from DB
}