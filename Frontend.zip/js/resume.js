// Global Search for Resume Studio
function filterResume() {
    const query = document.getElementById('resumeSearch').value.toLowerCase();
    const modules = document.querySelectorAll('.doc-section');
    const intro = document.querySelector('.page-intro');
    const empty = document.getElementById('noResults');
    let found = 0;

    modules.forEach(card => {
        const text = card.innerText.toLowerCase();
        if (text.includes(query)) {
            card.style.display = "block";
            found++;
        } else {
            card.style.display = "none";
        }
    });

    if (intro) {
        intro.style.display = (found > 0 || query === "") ? "block" : "none";
    }

    if (empty) {
        empty.style.display = (found === 0 && query !== "") ? "block" : "none";
    }
}

// Resume Draft Persistence
const resumeInput = document.getElementById('resumeNotes');
const RESUME_KEY = 'mountreach_resume_draft';

window.addEventListener('load', () => {
    const saved = localStorage.getItem(RESUME_KEY);
    if (saved && resumeInput) resumeInput.value = saved;
});

if (resumeInput) {
    resumeInput.addEventListener('input', () => {
        localStorage.setItem(RESUME_KEY, resumeInput.value);
    });
}

function clearResumeNotes() {
    if (confirm("Delete your resume draft?")) {
        resumeInput.value = "";
        localStorage.removeItem(RESUME_KEY);
    }
}